"use strict";
var Departure = (function () {
    function Departure() {
    }
    return Departure;
}());
exports.Departure = Departure;
var Stop = (function () {
    function Stop() {
    }
    return Stop;
}());
exports.Stop = Stop;
var DeparturesData = (function () {
    function DeparturesData() {
    }
    return DeparturesData;
}());
exports.DeparturesData = DeparturesData;
//# sourceMappingURL=departures.js.map