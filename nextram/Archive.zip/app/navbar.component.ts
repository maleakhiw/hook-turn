import { Component } from '@angular/core';

@Component({
  selector: 'navbar',
  templateUrl: './partials/navbar.html'
})
export class NavbarComponent { }
